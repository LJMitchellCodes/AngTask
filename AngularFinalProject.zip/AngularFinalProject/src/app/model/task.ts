export class Task {
    'id': number;
    'taskName': string;
    'taskDuedate': number;
    'taskCompleted': boolean;
}
